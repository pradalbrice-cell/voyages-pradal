# Voyages Pradal — déploiement

Contenu du dossier :
- `index.html` — l'application (liste des voyages + éditeur d'itinéraire)
- `manifest.json` — description de l'app pour l'installation (PWA)
- `sw.js` — service worker (fonctionnement hors-ligne)
- `icons/` — icônes 192px et 512px

## Étape A — Déployer sur GitHub Pages

1. Sur github.com, une fois connecté : **New repository**. Nom suggéré : `voyages-pradal`. Le laisser **public** (obligatoire pour GitHub Pages gratuit). Ne pas cocher "Add a README" si tu importes ce dossier tel quel.
2. Dans le nouveau dépôt, utiliser **Add file → Upload files**, glisser-déposer tout le contenu de ce dossier (`index.html`, `manifest.json`, `sw.js`, et le dossier `icons/`), puis **Commit changes**.
3. Aller dans **Settings → Pages** du dépôt.
4. Sous "Build and deployment", choisir **Source : Deploy from a branch**, branche `main`, dossier `/ (root)`. Enregistrer.
5. Après une à deux minutes, l'URL du site apparaît en haut de cette même page, du type :
   `https://TON-PSEUDO.github.io/voyages-pradal/`
6. Vérifier que le site s'affiche bien à cette adresse avant de passer à l'étape B.

## Étape B — Générer le .apk avec PWABuilder

1. Aller sur [pwabuilder.com](https://www.pwabuilder.com).
2. Coller l'URL obtenue à l'étape A (avec le `/` final), puis lancer l'analyse.
3. PWABuilder doit détecter le `manifest.json` et le service worker automatiquement. S'il signale un score partiel sur les icônes ou le manifest, ce n'est pas bloquant pour un usage personnel.
4. Choisir **Android**, générer le paquet. Télécharger l'archive : elle contient un `.apk` (à installer directement sur le téléphone pour tester) et un `.aab` (uniquement utile pour publier sur le Play Store).
5. Dans la même archive, PWABuilder fournit aussi un fichier `assetlinks.json` et l'empreinte SHA-256 associée.

## Étape C — Supprimer la barre d'adresse (assetlinks.json)

1. Créer un dossier `.well-known` à la racine du dépôt GitHub, y déposer le `assetlinks.json` fourni par PWABuilder.
2. Vérifier qu'il est bien servi à l'adresse :
   `https://TON-PSEUDO.github.io/voyages-pradal/.well-known/assetlinks.json`
   (tester avec un simple copier-coller de l'URL dans un navigateur : le contenu JSON doit s'afficher).
3. Si rien ne s'affiche : ajouter un fichier vide nommé `.nojekyll` à la racine du dépôt (GitHub Pages ignore par défaut les dossiers commençant par un point), puis recommit.
4. Réinstaller le `.apk` sur le téléphone : la barre d'adresse de Chrome ne doit plus apparaître.

## À conserver précieusement

Le fichier de clé de signature (`.jks`/keystore) généré par PWABuilder, et son mot de passe : nécessaires pour toute future mise à jour du `.apk`.

## Pour installer le `.apk` sur un téléphone Android

Le fichier n'étant pas passé par le Play Store, Android demandera d'autoriser "l'installation depuis une source inconnue" lors du premier lancement du fichier — c'est normal pour une app de test personnelle.
