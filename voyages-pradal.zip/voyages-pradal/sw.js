// Service worker — Voyages Pradal
// Stratégie : cache-first sur l'app shell (HTML/CSS/JS/icônes + librairies externes),
// pour que l'application s'affiche même sans connexion.
// Seules les tuiles de carte (OpenStreetMap) nécessitent une connexion active.

const CACHE_NAME = 'voyages-pradal-shell-v1';

const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js',
  'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;0,9..144,700;1,9..144,500&family=Work+Sans:wght@400;500;600&display=swap'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      // On tente de tout mettre en cache ; une ressource externe indisponible
      // au moment de l'installation ne doit pas bloquer l'app.
      return Promise.all(
        APP_SHELL.map((url) =>
          cache.add(url).catch(() => null)
        )
      );
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;

  // Les tuiles de carte OpenStreetMap : réseau uniquement, on ne les met pas
  // en cache (volume trop important, et la carte peut légitimement échouer hors-ligne).
  if (req.url.includes('tile.openstreetmap.org')) {
    return;
  }

  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req)
        .then((response) => {
          // Met en cache dynamiquement toute nouvelle ressource same-origin ou CDN
          // récupérée avec succès, pour la rendre disponible hors-ligne la prochaine fois.
          if (response && response.status === 200) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
          }
          return response;
        })
        .catch(() => {
          // Hors-ligne et pas en cache : pour une navigation, on retombe sur l'app shell.
          if (req.mode === 'navigate') {
            return caches.match('./index.html');
          }
          return new Response('', { status: 408, statusText: 'Hors-ligne' });
        });
    })
  );
});
